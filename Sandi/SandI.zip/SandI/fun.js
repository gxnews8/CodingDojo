$(document).ready(function () {
  // $('body').click(function () {
  //   $('body').fadeOut(function () {
  //     console.log($('body'))
  //     alert('fade out')
  //   })
  // })
  // ...
  $('.blah').click(function () {
    console.log(this)
    $(this).fadeOut()
  })
})
