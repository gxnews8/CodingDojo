﻿using System;
using System.Collections.Generic;

namespace ConsoleApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Console.WriteLine("Hello World!");
            List<object> Boxing = new List<object>();
            Boxing.Add(7);
            Boxing.Add(28);
            Boxing.Add(-1);
            Boxing.Add(true);
            Boxing.Add(false);
            Boxing.Add("chiair");
            Boxing.Add("Coding Dojo");

            foreach(var item in Boxing)
            {
                System.Console.WriteLine(item);
            }
            int sum = 0;
            for (int i = 0; i < Boxing.Count; i++)
            {
                if (Boxing[i] is int)
                {
                    System.Console.WriteLine("This is number and sum them:");
                    sum += (int)Boxing[i];
                    System.Console.WriteLine(sum);
                }
                else if (Boxing[i] is bool)
                {
                    System.Console.WriteLine("This is bool:");
                    System.Console.WriteLine(Boxing[i]);
                }
                else if (Boxing[i] is string)
                {
                    System.Console.WriteLine("This is string:");
                    System.Console.WriteLine(Boxing[i]);
                }
                else
                {
                    System.Console.WriteLine("Have this kind type?");
                }
            }
        }
    }
}
