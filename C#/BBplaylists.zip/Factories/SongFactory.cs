using System;
using System.Collections.Generic;
using System.Data;
using loginreg.Models;
using loginreg.ViewModels;
using MySql.Data.MySqlClient;
using Microsoft.AspNetCore.Identity;
using System.Linq; 
using Dapper;
using Microsoft.Extensions.Options;

namespace loginreg.Factories {
    
    public class SongFactory : IFactory<Song>
    {
        private readonly IOptions<MySqlOptions> config;
        public SongFactory(IOptions<MySqlOptions> conf) {
            config = conf;
        }
        internal IDbConnection Connection {
            get {
                return new MySqlConnection(config.Value.ConnectionString);
            }
        }

        public List<Song> FindAll() {
            using(IDbConnection dbConnection = Connection) {
                string query = "SELECT * FROM songs ORDER BY id DESC";
                dbConnection.Open();
                return dbConnection.Query<Song>(query).ToList();
            }
        }
        public Song FindById(int id) {
            using(IDbConnection dbConnection = Connection){
                string query = $"SElECT * FROM songs WHERE id = {id}";
                dbConnection.Open();
                return dbConnection.Query<Song>(@query).SingleOrDefault();
            }
        }

        public void Add(Song newSong) {
            using(IDbConnection dbConnection = Connection) {
                string query = "INSERT INTO songs (title, artist, count, created_at, updated_at) VALUES (@title, @artist, @count, NOW(), NOW())";
                dbConnection.Open();
                dbConnection.Execute(query, newSong);
            }
        }
    }
}