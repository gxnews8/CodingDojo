using System;
using System.Collections.Generic;
using System.Data;
using loginreg.Models;
using loginreg.ViewModels;
using MySql.Data.MySqlClient;
using Microsoft.AspNetCore.Identity;
using System.Linq; 
using Dapper;
using Microsoft.Extensions.Options;

namespace loginreg.Factories {
    
    public class PlaylistFactory : IFactory<Playlist>
    {
        private readonly IOptions<MySqlOptions> config;
        public PlaylistFactory(IOptions<MySqlOptions> conf) {
            config = conf;
        }
        internal IDbConnection Connection {
            get {
                return new MySqlConnection(config.Value.ConnectionString);
            }
        }

        public List<Playlist> FindAll() {
            using(IDbConnection dbConnection = Connection) {
                string query = "SELECT * FROM songs ORDER BY id DESC";
                dbConnection.Open();
                return dbConnection.Query<Playlist>(query).ToList();
            }
        }

        public List<Playlist> PlaylistsForSong(int songId) {
            using(IDbConnection dbConnection = Connection) {
                string query = $"SELECT * FROM playlists join users on playlists.user_id where users.id = playlists.user_id AND playlists.song_id = {songId}";
                dbConnection.Open();
                return dbConnection.Query<Playlist, User, Playlist>(query, (play, user) => {
                    play.user = user;
                    return play;
                }).ToList();
            }
        }
        public List<Playlist> PlaylistsForUser(int userid) {
            using(IDbConnection dbConnection = Connection) {
                string query = $"SELECT * FROM playlists join songs on playlists.song_id where songs.id = playlists.song_id AND playlists.user_id = {userid}";
                dbConnection.Open();
                return dbConnection.Query<Playlist, Song, Playlist>(query, (play, song) => {
                    play.song = song;
                    return play;
                }).ToList();
            }
        }
        public void AddToPlaylist(int songId, int userId) {
            Playlist effPlaylist = FindSinglePlaylist(songId, userId);
            if(effPlaylist == null) {
                using(IDbConnection dbConnection = Connection) {
                    string query = $"INSERT INTO playlists (user_id, song_id, count) VALUES ({userId}, {songId}, 1)";
                    dbConnection.Open();
                    dbConnection.Execute(query);
                }
            } else {
                using(IDbConnection dbConnection = Connection) {
                    string query = $"UPDATE playlists SET count = count + 1 WHERE id = {effPlaylist.id}";
                    dbConnection.Open();
                    dbConnection.Execute(query);
                }
            }
            using(IDbConnection dbConnection = Connection) {
                string query = $"UPDATE songs SET count = count + 1 WHERE id = {songId}";
                dbConnection.Open();
                dbConnection.Execute(query);
                return;
            }
        }

        public Playlist FindSinglePlaylist(int songId, int userId) {
            using(IDbConnection dbConnection = Connection) {
                string query = $"SELECT * FROM playlists where user_id = {userId} AND song_id = {songId}";
                dbConnection.Open();
                return dbConnection.Query<Playlist>(query).SingleOrDefault();
            }
        }
    }
}