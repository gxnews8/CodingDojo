using System;

namespace loginreg.Models {
    public class BaseEntity {
        public int id {get; set;}
        public DateTime created_at {get; set;}
    }
}