using System.ComponentModel.DataAnnotations;

namespace loginreg.Models {
    public class Song : BaseEntity {
        [Required]
        [MinLengthAttribute(2)]
        [DisplayAttribute(Name = "Song Title")]
        public string title {get; set;}
        [Required]
        [MinLengthAttribute(2)]
        [DisplayAttribute(Name = "Artist Name")]
        public string artist {get; set;}
        public int count {get; set;}

        public Song() {
            count = 0;
        }
    }
}