namespace loginreg.Models {
    public class User : BaseEntity {
        public string FirstName {get; set;}
        public string LastName {get; set;}
        public string password {get; set;}
        public string email {get; set;}
    }
}