namespace loginreg.Models {
    public class Playlist : BaseEntity {
        public int user_id {get; set;}
        public int song_id {get; set;}
        public User user { get; set;}
        public Song song { get; set;}
        public int count {get; set;}
    }
}