using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using loginreg.Models;
using loginreg.Factories;
using loginreg.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;

namespace loginreg.Controllers
{
    public class UserController : Controller
    {
        private readonly UserFactory userfactory;
        private readonly PlaylistFactory playlistfactory;

        public UserController(UserFactory UserFactory, PlaylistFactory PlaylistFactory) {
            userfactory = UserFactory;
            playlistfactory = PlaylistFactory;
        }

        [HttpGet]
        [Route("register")]
        public IActionResult Register() {
            return View("Register");
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("register")]
        public IActionResult Register(RegisterViewModel regModel) {
            if(ModelState.IsValid) {
                User newUser = userfactory.Add(regModel);
                HttpContext.Session.SetInt32("userid", newUser.id);
                return RedirectToAction("Index", "Song");
            }
            return View("Register");
        }

        [HttpGet]
        [Route("login")]
        public IActionResult Login() {
            return View("Login");
        }

        [HttpPost]
        [Route("login")]
        public IActionResult Login(LoginViewModel logModel) {
            if(ModelState.IsValid) {
                User LoggedUser = userfactory.FindByEmail(logModel.email);
                if(LoggedUser != null) {
                    HttpContext.Session.SetInt32("userid", LoggedUser.id);
                    return RedirectToAction("Index", "Song");
                }
            }
            return View("Login");
        }

        [HttpGet]
        [RouteAttribute("logout")]
        public IActionResult Logout() {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

        [HttpGet]
        [RouteAttribute("user/{userid}")]
        public IActionResult Show(int userid) {
            if(HttpContext.Session.GetInt32("userid") == null) {
                return RedirectToAction("Login", "User");
            }
            ViewBag.songsForUser = playlistfactory.PlaylistsForUser(userid);
            User curUser = userfactory.FindById(userid);
            return View("ShowUser", curUser);
        }
    }
}
