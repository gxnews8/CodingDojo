using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using loginreg.Models;
using loginreg.Factories;
using loginreg.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;

namespace loginreg.Controllers
{
    public class SongController : Controller
    {
        private readonly UserFactory userfactory;
        private readonly SongFactory songfactory;
        private readonly PlaylistFactory playlistfactory;

        public SongController(UserFactory UserFactory, SongFactory SongFactory, PlaylistFactory PlaylistFactory) {
            userfactory = UserFactory;
            songfactory = SongFactory;
            playlistfactory = PlaylistFactory;
        }
        // GET: /Home/
        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
            if(HttpContext.Session.GetInt32("userid") == null) {
                return RedirectToAction("Login", "User");
            }
            User curUser = userfactory.FindById((int)HttpContext.Session.GetInt32("userid"));
            ViewBag.FirstName = curUser.FirstName;
            ViewBag.LastName = curUser.LastName;
            ViewBag.allSongs = songfactory.FindAll();
            return View();
        }

        [HttpPost]
        [RouteAttribute("Create")]
        public IActionResult Create(Song newSong) {
            if(HttpContext.Session.GetInt32("userid") == null) {
                return RedirectToAction("Login", "User");
            }
            if(ModelState.IsValid) {
                //Save the new song
                songfactory.Add(newSong);
                return RedirectToAction("Index");
            }
            //REFACTOR!!
            User curUser = userfactory.FindById((int)HttpContext.Session.GetInt32("userid"));
            ViewBag.FirstName = curUser.FirstName;
            ViewBag.LastName = curUser.LastName;
            ViewBag.allSongs = songfactory.FindAll();
            return View("Index");
        }

        [HttpGet]
        [RouteAttribute("song/{id}")]
        public IActionResult Show(int id) {
            if(HttpContext.Session.GetInt32("userid") == null) {
                return RedirectToAction("Login", "User");
            }
            Song curSong = songfactory.FindById(id);
            ViewBag.usersForSong = playlistfactory.PlaylistsForSong(id);
            return View("SingleLadiesSongPage", curSong);
        }

        [HttpPost]
        [RouteAttribute("/AddToPlaylist/{songId}")]
        public IActionResult AddToPlaylist(int songId) {
            if(HttpContext.Session.GetInt32("userid") == null) {
                return RedirectToAction("Login", "User");
            }
            int userId = (int)HttpContext.Session.GetInt32("userid");
            playlistfactory.AddToPlaylist(songId, userId);
            return RedirectToAction("Index");
        }
    }
}