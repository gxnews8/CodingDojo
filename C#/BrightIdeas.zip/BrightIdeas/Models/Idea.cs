using System;
using System.Collections.Generic;

namespace many2many.Models
{
    public class Idea : BaseEntity
    {
        public int IdeaId { get; set; }
        public string Content { get; set; }
        public int Endorsements { get; set; }
        public List<Like> Likes { get; set; }
        public Idea(){
            Likes = new List<Like>();
            CreatedAt = DateTime.Now;
            UpdatedAt = DateTime.Now;
        }
        
    }
}