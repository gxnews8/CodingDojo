using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace many2many.Models
{
    public class User : BaseEntity
    {
        public int UserId {get; set;}
        [Required]
        [MinLengthAttribute(2)]
        public string Name {get; set;}
        [Required]
        [MinLengthAttribute(2)]
        public string Alias {get; set;}
        [Required]
        [DataTypeAttribute(DataType.EmailAddress)]
        public string Email {get; set;}
        [Required]
        [DataType(DataType.Password)]
        public string Password {get; set;}
        [NotMapped]
        [CompareAttribute("Password")]
        [DataType(DataType.Password)]
        public string Confirm {get; set;}
        public List<Like> Likes { get; set; }
        public User(){
            Likes = new List<Like>();
            CreatedAt = DateTime.Now;
            UpdatedAt = DateTime.Now;
        }
    }
}