using Microsoft.EntityFrameworkCore;
namespace many2many.Models
{
    public class MyContext : DbContext{
		public MyContext(DbContextOptions<MyContext> options) : base(options)
		{
		}
		// For each model you need to CRUD
		public DbSet<User> Users {get;set;}
		// e.g. public DbSet<Car> Cars {get;set;}
		public DbSet<Idea> Ideas {get; set;}
		public DbSet<Like> Likes {get; set;}
	}
}
