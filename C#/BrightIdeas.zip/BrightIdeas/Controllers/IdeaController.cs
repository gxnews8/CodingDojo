using System;
using System.Collections.Generic;
using System.Linq;
using many2many.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace many2many.Controllers
{
    public class IdeaController : Controller
    {
        private MyContext _context;
        public IdeaController(MyContext context)
        {
        	_context = context;
        }
        // GET: /Bright_Ideas/
        [HttpGet]
        [Route("bright_ideas")]
        public IActionResult Bright_Ideas()
        {
            int? userId = HttpContext.Session.GetInt32("user_id");
            if(userId == null)
            {
                return RedirectToAction("Main", "User");
            }
            User uzer = _context.Users.SingleOrDefault(u => u.UserId == userId);
            List<Like> likes = _context.Likes
                .Include(l => l.User)
                .Include(l => l.Idea)
                .ToList();
            ViewBag.User = uzer;
            ViewBag.Likes = likes;
            // List<Like> lists = new List<Like>();
            // var g = lists.GroupBy(l => l.IdeaId).ToList();
            // ViewBag.User = uzer;
            // ViewBag.Likes = g;
            return View("Bright_Ideas");
        }
        // Likes
        [HttpGet]
        [Route("bright_ideas/{IdeaId}")]
        public IActionResult List_Ideas(int IdeaId)
        {
            int? userId = HttpContext.Session.GetInt32("user_id");
            if(userId == null)
            {
                return RedirectToAction("Main", "User");
            }
            // Idea idea = _context.Ideas.SingleOrDefault(i => i.IdeaId == IdeaId);
            List<Idea> ideas = _context.Ideas
                // .Include(i => i.User)
                .ToList();
            // ViewBag.Likes = likes;
            ViewBag.Ideas = ideas;
            return View("List_Ideas");
        }
        // AddIdea
        [HttpGet]
        [Route("addIdea")]
        public IActionResult AddIdea()
        {
            int? userId = HttpContext.Session.GetInt32("user_id");
            if (userId == null)
            {
                return RedirectToAction("Main", "User");
            }
            ViewBag.userId = userId;
            return View();
        }
        [HttpPost]
        [Route("addIdea")]
        public IActionResult AddIdea(Idea newIdea)
        {
            int? userId = HttpContext.Session.GetInt32("user_id");
            if (userId == null)
            {
                return RedirectToAction("Main", "User");
            }
            if (ModelState.IsValid)
            {
                _context.Add(newIdea);
                _context.SaveChanges();
                Idea createdIdea = _context.Ideas.SingleOrDefault(a => a.IdeaId == newIdea.IdeaId);
                Like newLike = new Like {
                    UserId = (int)HttpContext.Session.GetInt32("user_id"),
                    IdeaId = createdIdea.IdeaId
                };
                _context.Add(newLike);
                _context.SaveChanges();
                return RedirectToAction("Bright_Ideas", "Idea");
            }
            return View("Bright_Ideas", newIdea);
        }
        // Join
        [HttpGet]
        [Route("like/{IdeaId}")]
        public IActionResult Like(int IdeaId)
        {
            Idea getIdea = _context.Ideas.SingleOrDefault(e => e.IdeaId == IdeaId);
            Like getCreator = _context.Likes.SingleOrDefault(j => j.IdeaId == IdeaId);
            Like newLike = new Like {
                UserId = (int)HttpContext.Session.GetInt32("user_id"),
                IdeaId = IdeaId
            };
            _context.Add<Like>(newLike);
            getIdea.Endorsements += 1;
            _context.Update<Idea>(getIdea);
            _context.SaveChanges();
            return RedirectToAction("Bright_Ideas", "Idea");
        }
    }
}
