using System.Linq;
using many2many.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace many2many.Controllers
{
    public class UserController : Controller
    {
        private MyContext _context;
        public UserController(MyContext context)
        {
        	_context = context;
        }
        // GET: /Main/
        [HttpGet]
        [Route("")]
        public IActionResult Main()
        {
            return View();
        }
        // User
        [HttpGet]
        [Route("users/{UserId}")]
        public IActionResult ShowUser(int UserId)
        {
            var userInfo = _context.Users.FirstOrDefault((user) => user.UserId == UserId);
            ViewBag.info = userInfo;
            return View("ShowUser", "User");
        }
        [HttpPost]
        [RouteAttribute("login")]
        public IActionResult Login(User logUser)
        {
            var userLoggingIn = _context.Users.FirstOrDefault((user) => user.Email == logUser.Email);
            if (userLoggingIn != null)         
            {
                var Hasher = new PasswordHasher<User>();
                if(0 != Hasher.VerifyHashedPassword(userLoggingIn, userLoggingIn.Password, logUser.Password)) 
                {
                    HttpContext.Session.SetInt32("user_id", userLoggingIn.UserId);
                    return RedirectToAction("Bright_Ideas", "Idea");
                }
            }
            ViewBag.Message = "Username or password incorrect.";
            return View("Main");
        }
        [HttpPost]
        [RouteAttribute("register")]
        public IActionResult Register(User newUser) 
        {
            if (ModelState.IsValid)
            {
                var checkUser = _context.Users.Where((user) => user.Email == newUser.Email).Select(user => user.Email).FirstOrDefault();
                if (checkUser == newUser.Email)
                {
                    ViewBag.Message = "User with that email already exists!";
                    return View("Main");
                }
                // hash password and create a new user
                PasswordHasher<User> Hasher = new PasswordHasher<User>();
                newUser.Password = Hasher.HashPassword(newUser, newUser.Password);
                _context.Add<User>(newUser);
                _context.SaveChanges();
                ViewBag.Message = "Thanks for registering. Please log in.";
                return View("Main");
            }
            return View("Main");
        }
        [HttpGet]
        [RouteAttribute("logout")]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Main");
        }
    }
}
