﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace ConsoleApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Console.WriteLine("Hello World!");

            // Three Basic Arrays
            int[] arr = {0,1,2,3,4,5,6,7,8,9};
            string[] name = new string[4] { "Tim", "Martin", "Nikki", "Sara"};
            for (int i = 0; i < name.Length; i++)
            {
                Console.WriteLine("He is {0}", name[i]);
            }
            for (int i = 1; i <= 10; i++)
            {
                if (i %2 == 0)
                {
                    Console.WriteLine("False");
                }
                else
                {
                    Console.WriteLine("True");
                }
            }
            // Multiplication Table
            int[,] TimeTable = new int[10,10];
            for (int i = 1; i <= 10; i++)
            {
                Console.Write("[ ");
                for (int j = 1; j <= 10; j++)
                {
                    if (i*j <10) Console.Write(""+i * j + ",  ");
                    else if (j>0) Console.Write(""+i * j + ", ");
                }
                Console.Write("]\n");
            }
            // User Info Dictionary
            Dictionary<string, string> profile = new Dictionary<string, string>();
            profile.Add("Name", "King");
            profile.Add("FavoriteSport", "Baseball");
            profile.Add("Pets", "Tococat");
            profile.Add("likesIceCream", "True");

            foreach (KeyValuePair<string,string> info in profile)
            {
            Console.WriteLine(info.Key + " : " + info.Value);
            }
            // Create 4 different dictionaries holding information for the 4 people in the array you created earlier (Tim, Martin, Nikki, Sara).
            // Tim
            Dictionary<string, dynamic> Tim = new Dictionary<string, dynamic>();
            Tim.Add("Name", "Tim");
            Tim.Add("Favorite Sport", "Football");
            Tim.Add("Pets", "cat");
            Tim.Add("likes IceCream", "True");
            // Martin
            Dictionary<string, dynamic> Martin = new Dictionary<string, dynamic>();
            Martin.Add("Name", "Martin");
            Martin.Add("Favorite Sport", "Pingpongball");
            Martin.Add("Pets", "Dog");
            Martin.Add("likes IceCream", "False");
            // Nikki
            Dictionary<string, dynamic> Nikki = new Dictionary<string, dynamic>();
            Nikki.Add("Name", "Nikki");
            Nikki.Add("Favorite Sport", "Badminton");
            Nikki.Add("Pets", "Tococat");
            Nikki.Add("likes IceCream", "True");
            // Sara
            Dictionary<string, dynamic> Sara = new Dictionary<string, dynamic>();
            Sara.Add("Name", "Sara");
            Sara.Add("Favorite Sport", "Tennisball");
            Sara.Add("Pets", "Tococat");
            Sara.Add("likes IceCream", "False");
            // Create a list of dictionaries and add each user dictionary to it.
            List<dynamic> users = new List<dynamic>();
            users.Add(Tim);
            users.Add(Martin);
            users.Add(Nikki);
            users.Add(Sara);
            // Loop through the list and print out each field of the user's info.
            Console.WriteLine("Their profile are:");
            foreach (var user in users)
            {
                foreach (KeyValuePair<string, dynamic> entry in user)
                {
                    Console.WriteLine(entry.Key + " : " + entry.Value);
                }
            }
        }
    }
}
