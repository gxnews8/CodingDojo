using System;
using System.Collections.Generic;
using System.Linq;
using many2many.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace many2many.Controllers
{
    public class EventController : Controller
    {
        private MyContext _context;
        public EventController(MyContext context)
        {
        	_context = context;
        }
        // GET: /Dashboard/
        [HttpGet]
        [Route("dashboard")]
        public IActionResult Dashboard()
        {
            int? userId = HttpContext.Session.GetInt32("user_id");
            if(userId == null)
            {
                return RedirectToAction("Index", "User");
            }
            User uzer = _context.Users.SingleOrDefault(u => u.UserId == userId);
            List<Join> Joins = _context.Joins
                .Include(j => j.User)
                .Include(j => j.Event)
                .ToList();
            ViewBag.User = uzer;
            ViewBag.Joins = Joins;
            return View("Dashboard");
        }
        // AddEvent
        [HttpGet]
        [Route("addEvent")]
        public IActionResult AddEvent()
        {
            int? userId = HttpContext.Session.GetInt32("user_id");
            if (userId == null)
            {
                return RedirectToAction("Index", "User");
            }
            ViewBag.userId = userId;
            return View();
        }
        [HttpPost]
        [Route("addEvent")]
        public IActionResult AddEvent(Event newEvent)
        {
            int? userId = HttpContext.Session.GetInt32("user_id");
            if (userId == null)
            {
                return RedirectToAction("Index", "User");
            }
            if (ModelState.IsValid)
            {
                _context.Add(newEvent);
                _context.SaveChanges();
                Event createdEvent = _context.Events.SingleOrDefault(a => a.EventId == newEvent.EventId);
                Join newJoin = new Join {
                    UserId = (int)HttpContext.Session.GetInt32("user_id"),
                    CreatorId = (int)HttpContext.Session.GetInt32("user_id"),
                    EventId = createdEvent.EventId
                };
                _context.Add(newJoin);
                _context.SaveChanges();
                return RedirectToAction("Dashboard", "Event");
            }
            return View("Dashboard", newEvent);
        }
        // Join
        [HttpGet]
        [Route("join/{EventId}")]
        public IActionResult Join(int EventId)
        {
            Event getEvent = _context.Events.SingleOrDefault(e => e.EventId == EventId);
            Join getCreator = _context.Joins.SingleOrDefault(j => j.EventId == EventId);
            Join newJoin = new Join {
                UserId = (int)HttpContext.Session.GetInt32("user_id"),
                CreatorId = getCreator.CreatorId,
                EventId = EventId
            };
            _context.Add<Join>(newJoin);
            getEvent.Participants += 1;
            _context.Update<Event>(getEvent);
            _context.SaveChanges();
            return RedirectToAction("Dashboard", "Event");
        }
        // Leave
        [HttpGet]
        [Route("leave/{EventId}")]
        public IActionResult Leave(int EventId)
        {
            Event leaveEvent = _context.Events.SingleOrDefault(e => e.EventId == EventId);
            leaveEvent.Participants -= 1;
            _context.Update<Event>(leaveEvent);
            int? userId = HttpContext.Session.GetInt32("user_id");
            Join removeJoin = _context.Joins.SingleOrDefault(j => j.EventId == EventId && j.UserId == userId );
            _context.Joins.Remove(removeJoin);
            _context.SaveChanges();
            return RedirectToAction("Dashboard", "Event");
        }
        // Update
        [HttpGet]
        [Route("update/{EventId}")]
        public IActionResult UpdateEvent(int EventId)
        {
            int? userId = HttpContext.Session.GetInt32("user_id");
            if (userId == null)
            {
                return RedirectToAction("Index", "User");
            }
            Event updateEvent = _context.Events.SingleOrDefault(e => e.EventId == EventId);
            ViewBag.Event = updateEvent;
            return View();
        }
        [HttpPost]
        [Route("update/{EventId}")]
        public IActionResult UpdateEvent(Event updateEvent, int EventId)
        {
            // Event getEvent = _context.Events.SingleOrDefault(e => e.EventId == EventId);
            // if(getEvent != null){
            //     _context.Update<Event>(updateEvent);
            //     _context.SaveChanges();
            // }
            _context.Update(updateEvent);
            _context.SaveChanges();
            return RedirectToAction("Dashboard", "Event");
        }
        // Delete
        [HttpGet]
        [Route("delete/{EventId}")]
        public IActionResult Delete(int EventId)
        {
            Event removeEvent = _context.Events.SingleOrDefault(e => e.EventId == EventId);
            _context.Events.Remove(removeEvent);
            Join removeJoin = _context.Joins.SingleOrDefault(j => j.EventId == EventId);
            _context.Joins.Remove(removeJoin);
            _context.SaveChanges();
            return RedirectToAction("Dashboard", "Event");
        }
    }
}
