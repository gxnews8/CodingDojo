// Write your Javascript code.
$(function(){
    $('#Date').click(function(){
        this.attr("type", "Date");
    });
    $('#Time').click(function(){
        this.attr("type", "Time");
    });
});