using System;
using System.Collections.Generic;

namespace many2many.Models
{
    public class Event : BaseEntity
    {
        public int EventId { get; set; }
        public string Title { get; set; }
        public DateTime Date { get; set; }
        public DateTime Time { get; set; }
        public int Duration { get; set; }
        public string Item { get; set; }
        public string Description { get; set; }
        public int Participants { get; set; }
        public List<Join> Joins { get; set; }
        public Event(){
            Joins = new List<Join>();
            CreatedAt = DateTime.Now;
            UpdatedAt = DateTime.Now;
        }
        
    }
}