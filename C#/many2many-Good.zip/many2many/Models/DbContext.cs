using Microsoft.EntityFrameworkCore;
namespace many2many.Models
{
    public class MyContext : DbContext{
		public MyContext(DbContextOptions<MyContext> options) : base(options)
		{
		}
		// For each model you need to CRUD
		public DbSet<User> Users {get;set;}
		// e.g. public DbSet<Car> Cars {get;set;}
		public DbSet<Event> Events {get; set;}
		public DbSet<Join> Joins {get; set;}
	}
}
