using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace many2many.Models
{
    public class User : BaseEntity
    {
        public int UserId {get; set;}
        [Required]
        [MinLengthAttribute(2)]
        public string FirstName {get; set;}
        [Required]
        [MinLengthAttribute(2)]
        public string LastName {get; set;}
        [Required]
        [DataTypeAttribute(DataType.EmailAddress)]
        public string Email {get; set;}
        [Required]
        [DataType(DataType.Password)]
        public string Password {get; set;}
        [NotMapped]
        [CompareAttribute("Password")]
        [DataType(DataType.Password)]
        public string Confirm {get; set;}
        public List<Join> Joins { get; set; }
        public User(){
            Joins = new List<Join>();
            CreatedAt = DateTime.Now;
            UpdatedAt = DateTime.Now;
        }
    }
}