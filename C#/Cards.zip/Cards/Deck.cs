using System;
using System.Collections.Generic;

namespace MyCards
{
    public class Deck
    {
        public List<Card> cards;

        public Deck()
        {
            reset();
        }

        public void reset()
        {
            cards = new List<Card>();
            string[] suits = new string[4] {"Clubs", "Spades", "Hearts", "Diamonds"};
            for(int i =0; i < suits.Length; i++)
            {
                for(int j = i; j < 14; j++)
                {
                    cards.Add(new Card(suits[i], j));
                }
            }
        }

        public Card deal()
        {
            Card toReturn = cards[0];
            cards.RemoveAt(0);
            return toReturn;
        }

        public void shuffle()
        {
            Random rand = new Random();
            for(var i = cards.Count -1; i > 0; i--)
            {
                int randIdx = rand.Next(cards.Count - 1);
                Card swap = cards[i];
                cards[i] = cards[randIdx];
                cards[randIdx] = swap;
            }
        }

        public override string ToString()
        {
            string str = "";
            foreach(Card card in cards)
            {
                str += card + "\n";
            }
            return str;
        }
    }
}