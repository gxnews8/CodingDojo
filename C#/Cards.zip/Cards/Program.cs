﻿using System;

namespace MyCards
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Card King = new Card("Clubs", 5);
            Card Coding = new Card("Diamonds", 10);
            Card Dojo = new Card("Hearts", 8);
            Card Bellevue = new Card("Spades", 1);
            Deck KingDeck = new Deck();
            System.Console.WriteLine(KingDeck);
            KingDeck.shuffle();
            System.Console.WriteLine(KingDeck);
            Console.WriteLine("Hello World!");
        }
    }
}
