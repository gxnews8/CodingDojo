namespace MyCards
{
    public class Card
    {
        public int numberValue;
        public string cardName
        {
            get
            {
                if(numberValue > 1 && numberValue < 11)
                {
                    return numberValue.ToString();
                }
                else if(numberValue == 1)
                {
                    return "Ace";
                }
                else if(numberValue == 11)
                {
                    return "Jack";
                }
                else if(numberValue == 12)
                {
                    return "Queen";
                }
                else if(numberValue == 13)
                {
                    return "King";
                }
                else
                {
                    return "Joker";
                }
            }
        }
        public string suit;

        public Card(string cardSuit, int cardNumber)
        {
            suit = cardSuit;
            numberValue = cardNumber;
        }

        public override string ToString()
        {
            return cardName + " of " + suit;
        }
    }
}