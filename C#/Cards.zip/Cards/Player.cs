using System;
using System.Collections.Generic;

namespace MyCards
{
    public class Player
    {
        public string playerName {get; set;}

        public List<Card> playerCard = new List<Card>();

        public Player(string num)
        {
            playerName = num;
        }

        public void Draw(Deck deck)
        {
            playerCard.Add(deck.deal());
        }
    }
}